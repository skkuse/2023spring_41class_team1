from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout 
from .models import back4Model,userproblem
from rest_framework import status
from rest_framework import serializers
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
# from django.views.decorators.csrf import csrf_exempt
# from django.views.decorators import method_decorator
# @method_decorator(csrf_exempt,name='dispatch')
class UserProblemSerializer(serializers.ModelSerializer):
    class Meta:
        model = userproblem
        fields = '__all__'
class RegisterView(APIView):
    permission_classes = (AllowAny,)

    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')
        nickname = request.data.get('nickname')  
        password_config=request.data.get('password_config')
        if password!=password_config:
            return Response({'message': '유효하지 않은 요청'}, status=status.HTTP_400_BAD_REQUEST)
        

        
        user = User.objects.create_user(username=username, password=password)
        user.nickname = nickname
        user.save()
        # 필요한 추가 정보 저장
        # 닉네임 추가
        # 예시: user.profile.email = request.data.get('email')
        
        return Response({'message': '회원가입이 완료되었습니다.'})


class LoginView(APIView):
    permission_classes = (AllowAny,)

    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')

        # 인증
        user = authenticate(username=username, password=password)
        if user is not None:
            login(request, user)
            return Response({'message': '로그인이 완료되었습니다.'})
        else:
            return Response({'message': '로그인에 실패하였습니다.'}, status=400)
class LogoutView(APIView):
    def post(self, request):
        # 사용자 세션 종료
        logout(request)
        return Response({'message': '로그아웃이 완료되었습니다.'})
class DataListView(APIView):
    permission_classes = (AllowAny,)

    def post(self, request):
        data = userproblem.objects.all()
        serializer = UserProblemSerializer(data, many=True)
        return Response(serializer.data)

class SeenView(APIView):
    def post(self, request):
        
        level=request.data.get('level')
        number=request.data.get('number')
        user_index = request.data.get('user_id')
        user_problem = userproblem.objects.get(level=level, number=number)
        seen_values = eval(str(user_problem.seen)) or []  # 기존 값이 없는 경우 빈 리스트로 초기화
        if user_index not in seen_values:
            seen_values.append(user_index)

        user_problem.seen = seen_values
        user_problem.save()
        return Response("DB 파일 수정 완료")