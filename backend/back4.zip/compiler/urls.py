from django.urls import path
from . import views

urlpatterns = [
    path('compile_code/', views.compile_code, name='compile_code'),
    path('user_code_test/', views.user_code_test, name='user_code_test'),
    path('user_testcase_test/', views.user_testcase_test, name='user_testcase_test')
]