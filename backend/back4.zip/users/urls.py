from django.urls import path
from users.views import RegisterView, LoginView , LogoutView, DataListView, SeenView

app_name = 'users'

urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('login/', LoginView.as_view(), name='login'),
    path('logout/', LogoutView.as_view(), name='logout'),
    path('data/', DataListView.as_view(), name='data-list'),
    path('seen/', SeenView.as_view(), name='seen')
] 